<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
$text = $_GET['text'] ?? '';
$targetLang = $_GET['lang'] ?? 'fr';

if (empty($text) || $targetLang === 'en') {
    echo json_encode(['translated' => $text]);
    exit;
}
function googleTranslate($text, $targetLang) {
    $url = "https://translate.googleapis.com/translate_a/single?client=gtx&sl=auto&tl=" . $targetLang . "&dt=t&q=" . urlencode($text);
    
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_TIMEOUT, 10);
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    
    if ($httpCode == 200 && $response) {
        $data = json_decode($response, true);
        if (isset($data[0][0][0])) {
            return $data[0][0][0];
        }
    }
    return null;
}

$translated = googleTranslate($text, $targetLang);
if (!$translated) {
    $url = "https://api.mymemory.translated.net/get?q=" . urlencode($text) . "&langpair=en|" . $targetLang;
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_TIMEOUT, 10);
    $response = curl_exec($ch);
    curl_close($ch);
    $data = json_decode($response, true);
    $translated = $data['responseData']['translatedText'] ?? $text;
}
echo json_encode(['translated' => $translated]);
?>