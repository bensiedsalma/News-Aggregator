<?php
require_once 'connect.php';
try {
    $stmt = $pdo->query("SELECT DISTINCT category FROM articles WHERE category IS NOT NULL AND category != '' ORDER BY category");
    $categories = $stmt->fetchAll(PDO::FETCH_COLUMN);
    header('Content-Type: application/json');
    echo json_encode($categories);
} catch (PDOException $e) {
    echo json_encode([]);
}
?>