<?php
require 'connect.php';

$msg = strtolower($_POST['msg'] ?? '');
$keywords = array_filter(explode(' ', $msg));

if (empty($keywords)) {
    echo "Please type something.";
    exit;
}

$sql = "SELECT id, title FROM articles WHERE ";
$conditions = [];
$params = [];

foreach ($keywords as $word) {
    $conditions[] = "title LIKE ?";
    $params[] = "%$word%";
}

$sql .= implode(" OR ", $conditions);
$sql .= " ORDER BY published_at DESC LIMIT 5";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$results = $stmt->fetchAll(PDO::FETCH_ASSOC);

if (!$results) {
    echo "Sorry, I found no articles related to your request.";
} else {
    foreach ($results as $art) {
        echo "• <a href='article.php?id={$art['id']}' target='_blank'>{$art['title']}</a><br>";
    }
}