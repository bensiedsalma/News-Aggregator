<?php
$pdo = new PDO("mysql:host=localhost;dbname=news_aggregator;charset=utf8mb4","root","",[
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION
]);

$category = $_GET['category'] ?? 'all';

if ($category === 'all') {
    $stmt = $pdo->query("SELECT * FROM articles ORDER BY published_at DESC");
} else {
    $stmt = $pdo->prepare("SELECT * FROM articles WHERE category = ? ORDER BY published_at DESC");
    $stmt->execute([$category]);
}

echo json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));