<?php
$host = 'localhost';
$db   = 'news_aggregator'; 
$user = 'root';
$pass = '';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$db;charset=utf8mb4", $user, $pass, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION
    ]);

    $articles = json_decode(file_get_contents('data.json'), true);

    $sql = "INSERT INTO articles 
    (author, title, description, content, url, image, category, published_at, is_favorite) 
    VALUES (:author, :title, :description, :content, :url, :image, :category, :published_at, 0)";
    
    $stmt = $pdo->prepare($sql);

    foreach ($articles as $item) {

        $stmt->execute([
            ':author'       => $item['author'],
            ':title'        => $item['title'],
            ':description'  => $item['description'],
            ':content'      => $item['content'],  
            ':url'          => $item['url'],
            ':image'        => $item['image'],
            ':category'     => $item['category'],
            ':published_at' => $item['published_at'],
        ]);

        echo "Inserted: " . substr($item['title'], 0, 50) . "<br>";
    }

    echo "<h3>Import done successfully </h3>";

} catch (Exception $e) {
    echo "Erreur: " . $e->getMessage();
}