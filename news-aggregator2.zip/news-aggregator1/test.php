<?php 
// 1. Appel l'connexion o l-data f l-foq dyal l-page
require_once 'connect.php';
$stmt = $pdo->query("SELECT * FROM articles ORDER BY id DESC LIMIT 12");
$articles = $stmt->fetchAll();
?>

<div class="articles-container">
    <?php foreach ($articles as $article): ?>
        <div class="article-card">
            <img src="<?= $article['image'] ?>" alt="<?= htmlspecialchars($article['title']) ?>">
            
            <div class="content">
                <span class="category"><?= htmlspecialchars($article['category']) ?></span>
                <h2><?= htmlspecialchars($article['title']) ?></h2>
                <p><?= htmlspecialchars(substr($article['description'], 0, 120)) ?>...</p>
                
                <a href="<?= $article['url'] ?>" class="read-more">Read More</a>
            </div>
        </div>
    <?php endforeach; ?>
</div>