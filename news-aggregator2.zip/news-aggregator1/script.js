const grid = document.getElementById('articlesGrid');
const spinner = document.getElementById('loadingSpinner');
const fallback = 'https://images.unsplash.com/photo-1504711432869-efd597cdd042?auto=format&fit=crop&w=800&q=80';

let currentLang = 'en';
let currentArticles = [];
let currentPage = 1;
const articlesPerPage = 9;
const categoryColors = {
    'Technology': 'bg-primary-subtle text-primary',
    'Business': 'bg-success-subtle text-success',
    'World': 'bg-danger-subtle text-danger',
    'Health': 'bg-info-subtle text-info',
    'Sports': 'bg-warning-subtle text-warning',
    'Politics': 'bg-danger-subtle text-danger',
    'Culture': 'bg-secondary-subtle text-secondary',
    'Sport': 'bg-warning-subtle text-warning',
    'History': 'bg-dark-subtle text-dark'
};
// Traductions pour l'interface
const uiTranslations = {
    'en': {
        'NewsHub': 'NewsHub', 'All': 'All', 'Technology': 'Technology',
        'Business': 'Business', 'World': 'World', 'Politics': 'Politics',
        'Culture': 'Culture', 'Sport': 'Sport', 'History': 'History',
        'Health': 'Health', 'Quick Links': 'Quick Links', 'About Us': 'About Us',
        'Contact': 'Contact', 'Privacy Policy': 'Privacy Policy',
        'Terms of Service': 'Terms of Service', 'Categories': 'Categories',
        'Loading articles': 'Loading articles...', 'No articles in this category': 'No articles in this category',
        'Read More': 'Read More', 'Search': 'Search...', 'Show favorites': 'Show favorites',
        'Votre source fiable': 'Your trusted source for the latest local and international news. We decode the info for you, 24/7.',
        'Designed with': 'Designed with'
    },
    'fr': {
        'NewsHub': 'NewsHub', 'All': 'Tous', 'Technology': 'Technologie',
        'Business': 'Affaires', 'World': 'Monde', 'Politics': 'Politique',
        'Culture': 'Culture', 'Sport': 'Sport', 'History': 'Histoire',
        'Health': 'Santé', 'Quick Links': 'Liens rapides', 'About Us': 'À propos',
        'Contact': 'Contact', 'Privacy Policy': 'Confidentialité',
        'Terms of Service': 'Conditions', 'Categories': 'Catégories',
        'Loading articles': 'Chargement des articles...', 'No articles in this category': 'Aucun article dans cette catégorie',
        'Read More': 'Lire plus', 'Search': 'Rechercher...', 'Show favorites': 'Voir les favoris',
        'Votre source fiable': 'Votre source fiable pour les dernières actualités locales et internationales.',
        'Designed with': 'Conçu avec'
    },
    'es': {
        'NewsHub': 'NewsHub', 'All': 'Todos', 'Technology': 'Tecnología',
        'Business': 'Negocios', 'World': 'Mundo', 'Politics': 'Política',
        'Culture': 'Cultura', 'Sport': 'Deporte', 'History': 'Historia',
        'Health': 'Salud', 'Quick Links': 'Enlaces rápidos', 'About Us': 'Sobre nosotros',
        'Contact': 'Contacto', 'Privacy Policy': 'Privacidad',
        'Terms of Service': 'Términos', 'Categories': 'Categorías',
        'Loading articles': 'Cargando artículos...', 'No articles in this category': 'No hay artículos en esta categoría',
        'Read More': 'Leer más', 'Search': 'Buscar...', 'Show favorites': 'Mostrar favoritos',
        'Votre source fiable': 'Su fuente confiable para las últimas noticias.',
        'Designed with': 'Diseñado con'
    },
    'ar': {
        'NewsHub': 'نيوز هاب', 'All': 'الكل', 'Technology': 'تكنولوجيا',
        'Business': 'أعمال', 'World': 'عالم', 'Politics': 'سياسة',
        'Culture': 'ثقافة', 'Sport': 'رياضة', 'History': 'تاريخ',
        'Health': 'صحة', 'Quick Links': 'روابط سريعة', 'About Us': 'عنا',
        'Contact': 'اتصل', 'Privacy Policy': 'الخصوصية',
        'Terms of Service': 'الشروط', 'Categories': 'التصنيفات',
        'Loading articles': 'جاري تحميل المقالات...', 'No articles in this category': 'لا توجد مقالات في هذا القسم',
        'Read More': 'اقرأ المزيد', 'Search': 'بحث...', 'Show favorites': 'عرض المفضلة',
        'Votre source fiable': 'مصدرك الموثوق لأحدث الأخبار.',
        'Designed with': 'صمم بواسطة'
    }
};

function timeAgo(dateStr) {
    const diff = Math.floor((new Date() - new Date(dateStr)) / 1000);
    if (diff < 60) return 'just now';
    if (diff < 3600) return Math.floor(diff / 60) + ' min ago';
    if (diff < 86400) return Math.floor(diff / 3600) + ' hours ago';
    return Math.floor(diff / 86400) + ' days ago';
}

async function translateText(text, targetLang) {
    if (targetLang === 'en' || !text) return text;
    try {
        const res = await fetch(`translate_api.php?text=${encodeURIComponent(text)}&lang=${targetLang}`);
        const data = await res.json();
        return data.translated || text;
    } catch (error) {
        return text;
    }
}

function displayPage(page) {
    const start = (page - 1) * articlesPerPage;
    const end = start + articlesPerPage;
    const pageArticles = currentArticles.slice(start, end);
    grid.innerHTML = pageArticles.map(buildCard).join('');
    attachFavListeners();
    updatePagination();
}

function updatePagination() {
    const totalPages = Math.ceil(currentArticles.length / articlesPerPage);
    const pagination = document.getElementById('pagination');
    if (!pagination) return;
    
    if (totalPages <= 1) {
        pagination.innerHTML = '';
        return;
    }
    
    let html = '';
    
    // Previous button
    html += `<li class="page-item ${currentPage === 1 ? 'disabled' : ''}">
        <a class="page-link" href="#" data-page="${currentPage - 1}">&laquo;</a>
    </li>`;
    
    // Page numbers
    let startPage = Math.max(1, currentPage - 2);
    let endPage = Math.min(totalPages, currentPage + 2);
    
    if (startPage > 1) {
        html += `<li class="page-item"><a class="page-link" href="#" data-page="1">1</a></li>`;
        if (startPage > 2) html += `<li class="page-item disabled"><span class="page-link">...</span></li>`;
    }
    
    for (let i = startPage; i <= endPage; i++) {
        html += `<li class="page-item ${currentPage === i ? 'active' : ''}">
            <a class="page-link" href="#" data-page="${i}">${i}</a>
        </li>`;
    }
    
    if (endPage < totalPages) {
        if (endPage < totalPages - 1) html += `<li class="page-item disabled"><span class="page-link">...</span></li>`;
        html += `<li class="page-item"><a class="page-link" href="#" data-page="${totalPages}">${totalPages}</a></li>`;
    }
    
    // Next button
    html += `<li class="page-item ${currentPage === totalPages ? 'disabled' : ''}">
        <a class="page-link" href="#" data-page="${currentPage + 1}">&raquo;</a>
    </li>`;
    
    pagination.innerHTML = html;
    
    // Add click events
    document.querySelectorAll('#pagination .page-link').forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            const page = parseInt(this.dataset.page);
            if (page && !isNaN(page) && page !== currentPage && page >= 1 && page <= totalPages) {
                currentPage = page;
                displayPage(currentPage);
                window.scrollTo({ top: 0, behavior: 'smooth' });
            }
        });
    });
}

function translateUI() {
    if (currentLang === 'en') return;
    const t = uiTranslations[currentLang];
    if (!t) return;
    
    document.querySelectorAll('.category-link').forEach(link => {
        const category = link.dataset.category;
        if (category === 'all') link.textContent = t['All'];
        else if (t[category]) link.textContent = t[category];
    });
    document.getElementById('footerBrand') && (document.getElementById('footerBrand').textContent = t['NewsHub']);
    document.getElementById('footerDesc') && (document.getElementById('footerDesc').textContent = t['Votre source fiable']);
    document.getElementById('quickLinksTitle') && (document.getElementById('quickLinksTitle').textContent = t['Quick Links']);
    document.getElementById('categoriesTitle') && (document.getElementById('categoriesTitle').textContent = t['Categories']);
    document.getElementById('aboutLink') && (document.getElementById('aboutLink').textContent = t['About Us']);
    document.getElementById('contactLink') && (document.getElementById('contactLink').textContent = t['Contact']);
    document.getElementById('privacyLink') && (document.getElementById('privacyLink').textContent = t['Privacy Policy']);
    document.getElementById('termsLink') && (document.getElementById('termsLink').textContent = t['Terms of Service']);

    const searchInput = document.getElementById('searchInput');
    if (searchInput) searchInput.placeholder = t['Search'];
    
    const copyright = document.getElementById('copyright');
    if (copyright) {
        copyright.innerHTML = `© 2026 ${t['NewsHub']}. ${t['Designed with']} ❤️ by Karima & Salma.`;
    }
}

async function translateArticles(articles, targetLang) {
    if (targetLang === 'en') return articles;
    
    showTranslationLoader();
    const translatedArticles = [];
    
    for (let i = 0; i < articles.length; i++) {
        const article = articles[i];
        const translated = { ...article };
        translated.title = await translateText(article.title, targetLang);
        translated.description = await translateText(article.description || '', targetLang);
        translated.category = await translateText(article.category, targetLang);
        translatedArticles.push(translated);
        if ((i + 1) % 3 === 0 || i === articles.length - 1) {
            const start = (currentPage - 1) * articlesPerPage;
            const end = start + articlesPerPage;
            const pageArticles = translatedArticles.slice(start, end);
            if (pageArticles.length > 0) {
                grid.innerHTML = pageArticles.map(buildCard).join('');
                attachFavListeners();
            }
        }
    }
    
    hideTranslationLoader();
    return translatedArticles;
}

function showTranslationLoader() {
    let loader = document.getElementById('translationLoader');
    if (!loader) {
        loader = document.createElement('div');
        loader.id = 'translationLoader';
        loader.className = 'position-fixed top-50 start-50 translate-middle bg-dark text-white px-4 py-2 rounded shadow';
        loader.style.zIndex = '9999';
        loader.style.background = '#e63946';
        document.body.appendChild(loader);
    }
    loader.innerHTML = '<i class="bi bi-arrow-repeat me-2 spinner-border spinner-border-sm"></i> Translating...';
    loader.style.display = 'block';
}

function hideTranslationLoader() {
    const loader = document.getElementById('translationLoader');
    if (loader) loader.style.display = 'none';
}

function buildCard(a) {
    const badge = categoryColors[a.category] || 'bg-secondary-subtle text-secondary';
    const isFav = a.is_favorite == 1;
    const source = a.author || a.source || 'NewsHub';
    const desc = (a.description || '').substring(0, 110);
    const displayDesc = desc.length === 110 ? desc + '...' : desc;
    const timeText = currentLang !== 'en' ? translateTime(timeAgo(a.published_at)) : timeAgo(a.published_at);

    return `
    <div class="col-md-4 article-card-wrap"
         data-id="${a.id}"
         data-title="${(a.title || '').toLowerCase()}"
         data-category="${(a.category || '').toLowerCase()}">
        <div class="card shadow-sm h-100 border-0">
            <div class="position-relative">
                <img src="${a.image || fallback}" class="card-img-top"
                     style="height:200px;object-fit:cover"
                     onerror="this.src='${fallback}'">
                <button class="btn btn-light rounded-circle position-absolute top-0 end-0 m-3 fav-card-btn shadow-sm ${isFav ? 'active-fav' : ''}"
                        data-id="${a.id}">
                    <i class="bi ${isFav ? 'bi-heart-fill' : 'bi-heart'} heart-item"></i>
                </button>
            </div>
            <div class="card-body d-flex flex-column p-4">
                <div class="d-flex align-items-center gap-2 mb-3">
                    <span class="badge rounded-pill ${badge} px-3 py-2">${escapeHtml(a.category)}</span>
                    <small class="text-muted">${timeText}</small>
                </div>
                <h5 class="card-title mb-3 fw-bold" style="font-size:1rem;line-height:1.4">${escapeHtml(a.title)}</h5>
                <p class="card-text text-secondary mb-4 small">${escapeHtml(displayDesc)}</p>
                <div class="mt-auto d-flex justify-content-between align-items-center border-top pt-3">
                    <small class="text-muted fw-semibold">
                        <i class="bi bi-globe2 me-1"></i>${escapeHtml(source)}
                    </small>
                    <a href="article.php?id=${a.id}" class="text-primary fw-bold text-decoration-none">
                     ${uiTranslations[currentLang]?.['Read More'] || 'Read More'} <i class="bi bi-arrow-right ms-1"></i>
                    </a>
                </div>
            </div>
        </div>
    </div>`;
}

function translateTime(timeText) {
    const translations = {
        'just now': { fr: 'à l\'instant', es: 'ahora mismo', ar: 'الآن' },
        'min ago': { fr: 'min', es: 'min', ar: 'دقيقة' },
        'hours ago': { fr: 'heures', es: 'horas', ar: 'ساعات' },
        'days ago': { fr: 'jours', es: 'días', ar: 'أيام' }
    };
    for (const [key, values] of Object.entries(translations)) {
        if (timeText.includes(key)) {
            const translated = values[currentLang];
            if (translated) return timeText.replace(key, translated);
        }
    }
    return timeText;
}

function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

async function loadArticles(category = 'all', skipTranslate = false) {
    spinner.style.display = 'block';
    grid.innerHTML = '';
    currentPage = 1;

    try {
        const res = await fetch('api.php?category=' + category);
        let articles = await res.json();
        
        spinner.style.display = 'none';

        if (!articles.length) {
            const noArticlesMsg = uiTranslations[currentLang]?.['No articles in this category'] || 'No articles in this category';
            grid.innerHTML = `<div class="col-12 text-center py-5 text-muted">
                <i class="bi bi-newspaper fs-1 d-block mb-3"></i>
                <p>${noArticlesMsg}</p>
            </div>`;
            document.getElementById('pagination').innerHTML = '';
            return;
        }

        currentArticles = articles;
        
        if (currentLang !== 'en' && !skipTranslate) {
            currentArticles = await translateArticles(articles, currentLang);
        }
        
        displayPage(1);

    } catch (err) {
        spinner.style.display = 'none';
        grid.innerHTML = `<p class="text-danger">Error: ${err.message}</p>`;
    }
}

function attachCategoryEvents() {
    document.querySelectorAll('.category-link').forEach(link => {
        link.removeEventListener('click', handleCategoryClick);
        link.addEventListener('click', handleCategoryClick);
    });
}

async function handleCategoryClick(e) {
    e.preventDefault();
    document.querySelectorAll('.category-link').forEach(l => l.classList.remove('active'));
    this.classList.add('active');
    await loadArticles(this.dataset.category, true);
    
    const searchInput = document.getElementById('searchInput');
    if (searchInput) searchInput.value = '';
    
    if (showingFavs) {
        showingFavs = false;
        const favToggleIcon = document.getElementById('favToggle');
        if (favToggleIcon) favToggleIcon.style.color = '';
    }
}

function attachFavListeners() {
    document.querySelectorAll('.fav-card-btn').forEach(btn => {
        btn.removeEventListener('click', handleFavClick);
        btn.addEventListener('click', handleFavClick);
    });
}

async function handleFavClick(e) {
    const btn = e.currentTarget;
    const id = btn.dataset.id;
    const icon = btn.querySelector('i');
    
    try {
        const res = await fetch('toggle_fav.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: `id=${id}`
        });
        const data = await res.json();
        
        if (data.success) {
            const isFav = data.is_favorite == 1;
            icon.classList.toggle('bi-heart-fill', isFav);
            icon.classList.toggle('bi-heart', !isFav);
            btn.classList.toggle('active-fav', isFav);
            
            // Update currentArticles
            const articleIndex = currentArticles.findIndex(a => a.id == id);
            if (articleIndex !== -1) {
                currentArticles[articleIndex].is_favorite = isFav ? 1 : 0;
            }
        }
    } catch(e) {
        console.error(e);
    }
}

let showingFavs = false;
document.getElementById('favToggle').addEventListener('click', function() {
    showingFavs = !showingFavs;
    this.style.color = showingFavs ? '#e63946' : '';
    filterFavorites();
});

function filterFavorites() {
    if (showingFavs) {
        const favArticles = currentArticles.filter(a => a.is_favorite == 1);
        currentArticles = favArticles;
        currentPage = 1;
        displayPage(1);
    } else {
        const activeCategory = document.querySelector('.category-link.active');
        if (activeCategory) {
            loadArticles(activeCategory.dataset.category, true);
        }
    }
}

document.getElementById('searchInput').addEventListener('input', function(e) {
    filterBySearch(e.target.value.toLowerCase().trim());
});

function filterBySearch(searchTerm) {
    if (searchTerm === '') {
        const activeCategory = document.querySelector('.category-link.active');
        if (activeCategory) {
            loadArticles(activeCategory.dataset.category, true);
        }
        return;
    }
    
    const filtered = currentArticles.filter(article => 
        (article.title || '').toLowerCase().includes(searchTerm) || 
        (article.category || '').toLowerCase().includes(searchTerm)
    );
    
    currentArticles = filtered;
    currentPage = 1;
    displayPage(1);
}

document.querySelectorAll('.translate-option').forEach(option => {
    option.addEventListener('click', async function(e) {
        e.preventDefault();
        const lang = this.dataset.lang;
        
        if (lang === 'off') {
            currentLang = 'en';
            document.getElementById('translateToggle').style.color = '';
        } else {
            currentLang = lang;
            document.getElementById('translateToggle').style.color = '#e63946';
        }
        
        translateUI();
        
        const activeCategory = document.querySelector('.category-link.active');
        if (activeCategory) {
            await loadArticles(activeCategory.dataset.category, false);
        }
        
        const dropdown = bootstrap.Dropdown.getInstance(document.getElementById('translateToggle'));
        if (dropdown) dropdown.hide();
    });
});
// Dark Mode
const darkToggle = document.getElementById('darkToggle');
if (localStorage.getItem('darkMode') === 'true') {
    document.body.classList.add('dark-mode');
    darkToggle.classList.replace('bi-moon', 'bi-sun');
}
darkToggle.addEventListener('click', () => {
    document.body.classList.toggle('dark-mode');
    const isDark = document.body.classList.contains('dark-mode');
    localStorage.setItem('darkMode', isDark);
    darkToggle.classList.toggle('bi-moon', !isDark);
    darkToggle.classList.toggle('bi-sun', isDark);
});
const darkModeStyle = document.createElement('style');
darkModeStyle.textContent = `
    body.dark-mode { background-color: #1a1a2e; color: #ffffff; }
    body.dark-mode .navbar, body.dark-mode .card { background-color: #16213e !important; }
    body.dark-mode .card .text-secondary, body.dark-mode .card .text-muted { color: #cccccc !important; }
    body.dark-mode .bg-white { background-color: #16213e !important; }
    body.dark-mode .input-group-text, body.dark-mode .form-control { background-color: #0f3460; border-color: #0f3460; color: #ffffff; }
    body.dark-mode .form-control::placeholder { color: #cccccc; }
    body.dark-mode .navbar-brand, body.dark-mode .nav-link, body.dark-mode .card-title, body.dark-mode p { color: #ffffff !important; }
    body.dark-mode .badge { background-color: #ffffff !important; color: #1a1a2e !important; }
    body.dark-mode .fav-card-btn { background: #1a1a2e !important; border: 1px solid #fff; }
    body.dark-mode .fav-card-btn i { color: #ffffff !important; }
    body.dark-mode .active-fav { background-color: #e63946 !important; }
    body.dark-mode .border-top { border-top-color: #2a2a4a !important; }
    body.dark-mode .pagination .page-link { background-color: #16213e; color: #ffffff; border-color: #2a2a4a; }
    body.dark-mode .pagination .page-item.active .page-link { background-color: #e63946; color: white; border-color: #e63946; }
    body.dark-mode .pagination .page-item.disabled .page-link { background-color: #0f3460; color: #666; }
`;
document.head.appendChild(darkModeStyle);


// INIT
attachCategoryEvents();
loadArticles('all');

const chatToggle = document.getElementById('chatToggle');
const chatbot = document.getElementById('chatbot');
const closeChat = document.getElementById('closeChat');

chatToggle.addEventListener('click', () => {
    chatbot.style.display = 'block';
});

closeChat.addEventListener('click', () => {
    chatbot.style.display = 'none';
});

const chatBody = document.getElementById('chatBody');
const chatInput = document.getElementById('chatInput');
const sendBtn = document.getElementById('sendBtn');

function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

function addMessage(sender, text, isBot = false) {
    const div = document.createElement('div');
    div.className = 'mb-2';
    div.innerHTML = `
        <div class="${isBot ? 'text-primary' : 'text-dark'}">
            <b>${escapeHtml(sender)}:</b> 
            <span>${isBot ? text : escapeHtml(text)}</span>
        </div>
    `;
    chatBody.appendChild(div);
    chatBody.scrollTop = chatBody.scrollHeight;
}

function showTyping() {
    const div = document.createElement('div');
    div.className = 'mb-2 text-muted fst-italic';
    div.innerHTML = '<small>Bot is typing...</small>';
    chatBody.appendChild(div);
    return div;
}

function sendMessage() {
    const msg = chatInput.value.trim();
    if (!msg) return;

    addMessage('You', msg, false);
    chatInput.value = '';

    const typing = showTyping();

    fetch('chatbot.php', {
        method: 'POST',
        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
        body: 'msg=' + encodeURIComponent(msg)
    })
    .then(res => res.text())
    .then(reply => {
        typing.remove();
        addMessage('Bot', reply, true);
    })
    .catch(() => {
        typing.remove();
        addMessage('Bot', 'Error, try again.', true);
    });
}

sendBtn.addEventListener('click', sendMessage);
chatInput.addEventListener('keydown', e => {
    if (e.key === 'Enter') sendMessage();
});
