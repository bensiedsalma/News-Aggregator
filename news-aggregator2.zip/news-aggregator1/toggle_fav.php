<?php
// toggle_fav.php
header('Content-Type: application/json');

require_once 'connect.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = isset($_POST['id']) ? (int)$_POST['id'] : 0;
    
    if ($id > 0) {
        try {
            // Get current favorite status
            $stmt = $pdo->prepare("SELECT is_favorite FROM articles WHERE id = ?");
            $stmt->execute([$id]);
            $current = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if ($current) {
                $newStatus = $current['is_favorite'] == 1 ? 0 : 1;
                
                // Update favorite status
                $updateStmt = $pdo->prepare("UPDATE articles SET is_favorite = ? WHERE id = ?");
                $updateStmt->execute([$newStatus, $id]);
                
                echo json_encode([
                    'success' => true,
                    'is_favorite' => $newStatus
                ]);
            } else {
                echo json_encode(['success' => false, 'message' => 'Article not found']);
            }
        } catch (PDOException $e) {
            echo json_encode(['success' => false, 'message' => $e->getMessage()]);
        }
    } else {
        echo json_encode(['success' => false, 'message' => 'Invalid ID']);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
}
?>