<?php
require_once 'connect.php';
$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if ($id <= 0) {
    header('Location: index.html');
    exit;
}
try {
    $stmt = $pdo->prepare("SELECT * FROM articles WHERE id = ?");
    $stmt->execute([$id]);
    $article = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$article) {
        header('Location: index.html');
        exit;
    }

} catch (PDOException $e) {
    die("Error: " . $e->getMessage());
}
$publishedDate = date('F j, Y', strtotime($article['published_at']));
$timeAgo = timeAgo($article['published_at']);

function timeAgo($dateStr) {
    $diff = time() - strtotime($dateStr);
    if ($diff < 60) return 'just now';
    if ($diff < 3600) return floor($diff / 60) . ' min ago';
    if ($diff < 86400) return floor($diff / 3600) . ' hours ago';
    return floor($diff / 86400) . ' days ago';
}

// Category colors - SAME AS INDEX
$categoryColors = [
    'Technology' => 'bg-primary-subtle text-primary',
    'Business' => 'bg-success-subtle text-success',
    'World' => 'bg-danger-subtle text-danger',
    'Health' => 'bg-info-subtle text-info',
    'Politics' => 'bg-danger-subtle text-danger',
    'Culture' => 'bg-secondary-subtle text-secondary',
    'Sport' => 'bg-warning-subtle text-warning',
    'History' => 'bg-dark-subtle text-dark'
];
$badgeClass = $categoryColors[$article['category']] ?? 'bg-secondary-subtle text-secondary';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($article['title']); ?> | NewsHub</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
    <style>
        /* SAME CARD STYLE AS INDEX */
        .detail-card {
            border: none;
            border-radius: 16px;
            overflow: hidden;
            box-shadow: 0 8px 30px rgba(0,0,0,0.12);
            transition: transform 0.3s ease, box-shadow 0.3s ease;
            background: white;
        }
        
        .detail-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 15px 40px rgba(0,0,0,0.15);
        }

        .detail-image {
            height: 400px;
            object-fit: cover;
            width: 100%;
        }

        .detail-body {
            padding: 2.5rem;
        }

        .detail-badge {
            display: inline-flex;
            align-items: center;
            padding: 0.5rem 1rem;
            border-radius: 50px;
            font-size: 0.85rem;
            font-weight: 600;
            margin-bottom: 1rem;
        }

        .detail-title {
            font-size: 1.8rem;
            font-weight: 700;
            line-height: 1.3;
            margin-bottom: 1.5rem;
            color: #1a1a2e;
        }

        .detail-meta {
            display: flex;
            align-items: center;
            gap: 1.5rem;
            margin-bottom: 2rem;
            padding-bottom: 1.5rem;
            border-bottom: 2px solid #f0f0f0;
        }

        .detail-meta-item {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            color: #6c757d;
            font-size: 0.9rem;
        }

        /* DESCRIPTION WITHOUT QUOTE ICON */
        .detail-description {
            background: #f8f9fa;
            border-left: 4px solid #007bff;
            padding: 1.5rem;
            border-radius: 0 12px 12px 0;
            margin-bottom: 2rem;
            color: #495057;
        }

        .detail-content {
            font-size: 1.1rem;
            line-height: 1.8;
            color: #333;
            margin-bottom: 2rem;
        }

        .detail-content p {
            margin-bottom: 1.5rem;
        }

        /* SAME BUTTON STYLE AS INDEX CARDS */
        .btn-original {
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
            padding: 0.75rem 2rem;
            background: #007bff;
            color: white;
            text-decoration: none;
            border-radius: 50px;
            font-weight: 600;
            transition: all 0.3s ease;
            border: none;
        }

        .btn-original:hover {
            background: #0056b3;
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(0,123,255,0.3);
            color: white;
        }

        .btn-back {
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
            padding: 0.6rem 1.5rem;
            background: white;
            color: #333;
            text-decoration: none;
            border-radius: 50px;
            font-weight: 500;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            transition: all 0.3s ease;
            border: 1px solid #e0e0e0;
        }

        .btn-back:hover {
            transform: translateX(-5px);
            box-shadow: 0 5px 15px rgba(0,0,0,0.15);
            color: #007bff;
        }

        /* FAVORITE BUTTON SAME STYLE */
        .fav-btn-detail {
            width: 45px;
            height: 45px;
            border-radius: 50%;
            border: none;
            background: white;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            transition: all 0.3s ease;
        }

        .fav-btn-detail:hover {
            transform: scale(1.1);
            background: #ff6b6b;
        }

        .fav-btn-detail:hover i {
            color: white;
        }

        .fav-btn-detail.active-fav {
            background: #e63946;
        }

        .fav-btn-detail.active-fav i {
            color: white;
        }

        /* SHARE BUTTONS */
        .share-btn {
            width: 45px;
            height: 45px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            border: 1px solid #e0e0e0;
            background: white;
            color: #6c757d;
            transition: all 0.3s ease;
            text-decoration: none;
        }

        .share-btn:hover {
            transform: translateY(-3px);
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }

        .share-btn.twitter:hover { background: #1da1f2; color: white; border-color: #1da1f2; }
        .share-btn.facebook:hover { background: #4267B2; color: white; border-color: #4267B2; }
        .share-btn.whatsapp:hover { background: #25d366; color: white; border-color: #25d366; }
        .share-btn.copy:hover { background: #6c757d; color: white; border-color: #6c757d; }

        /* DARK MODE - SAME AS INDEX */
        body.dark-mode {
            background-color: #1a1a2e;
            color: #ffffff;
        }

        body.dark-mode .detail-card {
            background-color: #16213e;
        }

        body.dark-mode .detail-title {
            color: #ffffff;
        }

        body.dark-mode .detail-meta-item {
            color: #cccccc;
        }

        body.dark-mode .detail-description {
            background: #0f3460;
            color: #e0e0e0;
            border-left-color: #4dabf7;
        }

        body.dark-mode .detail-content {
            color: #e0e0e0;
        }

        body.dark-mode .btn-back {
            background: #16213e;
            color: #ffffff;
            border-color: #2a2a4a;
        }

        body.dark-mode .share-btn {
            background: #16213e;
            color: #ffffff;
            border-color: #2a2a4a;
        }

        /* RESPONSIVE */
        @media (max-width: 768px) {
            .detail-image {
                height: 250px;
            }
            .detail-body {
                padding: 1.5rem;
            }
            .detail-title {
                font-size: 1.4rem;
            }
        }
    </style>
</head>
<body>
    <!-- Navigation SAME AS INDEX -->
    <nav class="navbar navbar-expand-lg shadow-sm">
        <div class="container">
            <i class="bi bi-newspaper me-2" style="color: #007bff;"></i>
            <a class="navbar-brand fw-bold" href="index.html">NewsHub</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#nav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="nav">
                <ul class="navbar-nav mx-auto">
                    <li class="nav-item"><a class="nav-link" href="index.html">All</a></li>
                    <li class="nav-item"><a class="nav-link" href="index.html?category=Technology">Technology</a></li>
                    <li class="nav-item"><a class="nav-link" href="index.html?category=Business">Business</a></li>
                    <li class="nav-item"><a class="nav-link" href="index.html?category=World">World</a></li>
                    <li class="nav-item"><a class="nav-link" href="index.html?category=Politics">Politics</a></li>
                    <li class="nav-item"><a class="nav-link" href="index.html?category=Culture">Culture</a></li>
                    <li class="nav-item"><a class="nav-link" href="index.html?category=Sport">Sport</a></li>
                    <li class="nav-item"><a class="nav-link" href="index.html?category=History">History</a></li>
                </ul>
                <div class="d-flex align-items-center gap-3 fs-5">
                    <i class="bi bi-moon icon" id="darkToggle" style="cursor: pointer;"></i>
                </div>
            </div>
        </div>
    </nav>

    <div class="container my-5">
        <div class="row justify-content-center">
            <div class="col-lg-8">
                
                <!-- Back Button -->
                <a href="index.html" class="btn-back mb-4">
                    <i class="bi bi-arrow-left"></i>
                    Back to News
                </a>

                <!-- MAIN CARD - SAME STYLE AS INDEX -->
                <div class="detail-card">
                    <!-- Image -->
                    <img src="<?php echo htmlspecialchars($article['image']); ?>" 
                         class="detail-image"
                         alt="<?php echo htmlspecialchars($article['title']); ?>"
                         onerror="this.src='https://images.unsplash.com/photo-1504711432869-efd597cdd042?auto=format&fit=crop&w=800&q=80'">
                    
                    <!-- Body -->
                    <div class="detail-body">
                        <!-- Category Badge -->
                        <div class="d-flex justify-content-between align-items-start mb-3">
                            <span class="detail-badge <?php echo $badgeClass; ?>">
                                <?php echo htmlspecialchars($article['category']); ?>
                            </span>
                            
                            <!-- Favorite Button SAME AS INDEX -->
                            <button class="fav-btn-detail <?php echo $article['is_favorite'] ? 'active-fav' : ''; ?>" 
                                    onclick="toggleFavorite(<?php echo $article['id']; ?>, this)"
                                    title="Add to favorites">
                                <i class="bi <?php echo $article['is_favorite'] ? 'bi-heart-fill' : 'bi-heart'; ?>"></i>
                            </button>
                        </div>

                        <!-- Title -->
                        <h1 class="detail-title"><?php echo htmlspecialchars($article['title']); ?></h1>

                        <!-- Meta Info -->
                        <div class="detail-meta">
                            <span class="detail-meta-item">
                                <i class="bi bi-person"></i>
                                <?php echo htmlspecialchars($article['author'] ?: 'NewsHub'); ?>
                            </span>
                            <span class="detail-meta-item">
                                <i class="bi bi-calendar"></i>
                                <?php echo $publishedDate; ?>
                            </span>
                            <span class="detail-meta-item">
                                <i class="bi bi-clock"></i>
                                <?php echo $timeAgo; ?>
                            </span>
                        </div>

                        

                        <!-- Content -->
                        <div class="detail-content">
                            <?php 
                            $paragraphs = preg_split('/\n\s*\n/', $article['content']);
                            foreach ($paragraphs as $paragraph) {
                                $paragraph = trim($paragraph);
                                if (!empty($paragraph)) {
                                    echo '<p>' . nl2br(htmlspecialchars($paragraph)) . '</p>';
                                }
                            }
                            ?>
                        </div>

                        <!-- Original Link Button -->
                        <div class="text-center pt-4 border-top">
                            <a href="<?php echo htmlspecialchars($article['url']); ?>" target="_blank" class="btn-original">
                                Read Original Article
                                <i class="bi bi-box-arrow-up-right"></i>
                            </a>
                        </div>

                        <!-- Share Buttons -->
                        <div class="d-flex justify-content-center gap-3 mt-4 pt-3 border-top">
                            <a href="https://twitter.com/intent/tweet?url=<?php echo urlencode($article['url']); ?>&text=<?php echo urlencode($article['title']); ?>" 
                               target="_blank" class="share-btn twitter" title="Share on Twitter">
                                <i class="bi bi-twitter-x"></i>
                            </a>
                            <a href="https://www.facebook.com/sharer/sharer.php?u=<?php echo urlencode($article['url']); ?>" 
                               target="_blank" class="share-btn facebook" title="Share on Facebook">
                                <i class="bi bi-facebook"></i>
                            </a>
                            <a href="https://wa.me/?text=<?php echo urlencode($article['title'] . ' ' . $article['url']); ?>" 
                               target="_blank" class="share-btn whatsapp" title="Share on WhatsApp">
                                <i class="bi bi-whatsapp"></i>
                            </a>
                            <button onclick="copyLink()" class="share-btn copy" title="Copy link">
                                <i class="bi bi-link-45deg"></i>
                            </button>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>

    <!-- Footer SAME AS INDEX - WITHOUT SOURCE LINE -->
    <footer class="pt-5 pb-3 mt-5">
        <div class="container">
            <div class="border-top pt-3 mt-3 text-center">
                <p class="mb-0 small footer-copy">© 2026 NewsHub. Designed with ❤️ by Karima & Salma.</p>
            </div>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Toggle Favorite - SAME AS INDEX
        async function toggleFavorite(id, btn) {
            const icon = btn.querySelector('i');
            
            try {
                const res = await fetch('toggle_fav.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                    body: `id=${id}`
                });
                const data = await res.json();
                
                if (data.success) {
                    const isFav = data.is_favorite == 1;
                    icon.classList.toggle('bi-heart-fill', isFav);
                    icon.classList.toggle('bi-heart', !isFav);
                    btn.classList.toggle('active-fav', isFav);
                }
            } catch(e) {
                console.error(e);
            }
        }

        function copyLink() {
            navigator.clipboard.writeText(window.location.href).then(() => {
                alert('Link copied to clipboard!');
            });
        }

        const darkToggle = document.getElementById('darkToggle');
        if (localStorage.getItem('darkMode') === 'true') {
            document.body.classList.add('dark-mode');
            darkToggle.classList.replace('bi-moon', 'bi-sun');
        }
        darkToggle.addEventListener('click', () => {
            document.body.classList.toggle('dark-mode');
            const isDark = document.body.classList.contains('dark-mode');
            localStorage.setItem('darkMode', isDark);
            darkToggle.classList.toggle('bi-moon', !isDark);
            darkToggle.classList.toggle('bi-sun', isDark);
        });
    </script>
</body>
</html>   